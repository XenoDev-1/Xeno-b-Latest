Disable antivirus as it may delete the dll files. Then run Xeno.exe.
ENJOY!!